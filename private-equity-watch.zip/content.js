// content.js
// Runs on every page. Detects whether the current site or channel is owned
// by a private equity firm, then messages the background service worker so
// it can update the extension icon.
//
// Platform support:
//   youtube.com  — channel-level detection via URL, ytInitialData, and DOM
//   everything else — domain-level detection against PE_ENTITIES.domains

// ---------------------------------------------------------------------------
// Top-level dispatcher
// ---------------------------------------------------------------------------

function detectCurrentSite(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return { isWarning: false };
  }

  const hostname = parsed.hostname.replace(/^www\./, "").toLowerCase();

  if (hostname === "youtube.com" || hostname === "youtu.be") {
    return detectYouTube(parsed);
  }

  return detectByDomain(hostname);
}

// ---------------------------------------------------------------------------
// Generic domain detection (non-YouTube sites)
// ---------------------------------------------------------------------------

function detectByDomain(hostname) {
  if (PE_ENTITIES.domains.has(hostname)) {
    return { isWarning: true, ownerInfo: PE_ENTITIES.ownerInfo[hostname] };
  }
  return { isWarning: false };
}

// ---------------------------------------------------------------------------
// YouTube-specific detection
// ---------------------------------------------------------------------------

function detectYouTube(parsed) {
  const parts = parsed.pathname.split("/").filter(Boolean);

  // /@handle  (most common modern format)
  if (parts[0] && parts[0].startsWith("@")) {
    const handle = parts[0].slice(1).toLowerCase();
    if (PE_ENTITIES.youtubeHandles.has(handle)) {
      return { isWarning: true, ownerInfo: PE_ENTITIES.ownerInfo[handle] };
    }
    return { isWarning: false };
  }

  // /channel/UCxxx  (channel ID format)
  if (parts[0] === "channel" && parts[1]) {
    const id = parts[1].toLowerCase();
    if (PE_ENTITIES.youtubeHandles.has(id)) {
      return { isWarning: true, ownerInfo: PE_ENTITIES.ownerInfo[id] };
    }
  }

  // /c/slug  or  /user/username  (legacy formats)
  if ((parts[0] === "c" || parts[0] === "user") && parts[1]) {
    const slug = parts[1].toLowerCase();
    if (PE_ENTITIES.youtubeHandles.has(slug)) {
      return { isWarning: true, ownerInfo: PE_ENTITIES.ownerInfo[slug] };
    }
  }

  // /watch?v=xxx  or  /shorts/xxx  — channel not in URL, inspect page content
  if (parts[0] === "watch" || parts[0] === "shorts") {
    return detectFromYouTubePage();
  }

  return { isWarning: false };
}

function detectFromYouTubePage() {
  // Try ytInitialData (most reliable, YouTube sets this as a global)
  try {
    const ytData = window.ytInitialData;
    if (ytData) {
      const handle = extractHandleFromYtData(ytData);
      if (handle) {
        const lc = handle.toLowerCase();
        if (PE_ENTITIES.youtubeHandles.has(lc)) {
          return { isWarning: true, ownerInfo: PE_ENTITIES.ownerInfo[lc] };
        }
      }
    }
  } catch (_) {
    // ytInitialData structure can change; fall through to DOM
  }

  // DOM fallback: owner link rendered under the video
  const ownerLinks = document.querySelectorAll(
    "ytd-channel-name a, #owner #channel-name a, #upload-info #channel-name a"
  );
  for (const link of ownerLinks) {
    const href = link.getAttribute("href") || "";
    const match = href.match(/\/@([^/?]+)/) || href.match(/\/channel\/([^/?]+)/);
    if (match) {
      const id = match[1].toLowerCase();
      if (PE_ENTITIES.youtubeHandles.has(id)) {
        return { isWarning: true, ownerInfo: PE_ENTITIES.ownerInfo[id] };
      }
    }
  }

  return { isWarning: false };
}

function extractHandleFromYtData(ytData) {
  // Video watch page: owner info lives in videoSecondaryInfoRenderer
  try {
    const contents =
      ytData?.contents?.twoColumnWatchNextResults?.results?.results?.contents;
    if (Array.isArray(contents)) {
      for (const item of contents) {
        const renderer = item?.videoSecondaryInfoRenderer;
        if (!renderer) continue;
        const canonical =
          renderer?.owner?.videoOwnerRenderer?.navigationEndpoint
            ?.browseEndpoint?.canonicalBaseUrl;
        if (canonical) {
          return canonical.replace(/^\/@/, "");
        }
      }
    }
  } catch (_) {}

  // Channel page: header renderer
  try {
    const handle =
      ytData?.header?.c4TabbedHeaderRenderer?.navigationEndpoint
        ?.browseEndpoint?.canonicalBaseUrl;
    if (handle) return handle.replace(/^\/@/, "");
  } catch (_) {}

  return null;
}

// Export for the test environment
if (typeof module !== "undefined") {
  module.exports = { detectCurrentSite, detectByDomain, detectYouTube, extractHandleFromYtData };
}

// ---------------------------------------------------------------------------
// Browser-only: SPA navigation tracking and chrome messaging
// ---------------------------------------------------------------------------
(function () {
  if (typeof chrome === "undefined") return;

  let lastCheckedUrl = null;

  function checkCurrentPage() {
    const url = window.location.href;
    if (url === lastCheckedUrl) return;
    lastCheckedUrl = url;

    const result = detectCurrentSite(url);
    chrome.runtime.sendMessage({
      type: "PAGE_CHECK_RESULT",
      isWarning: result.isWarning,
      ownerInfo: result.ownerInfo || null,
    });
  }

  // YouTube fires this on every SPA navigation
  document.addEventListener("yt-navigate-finish", () => {
    lastCheckedUrl = null;
    checkCurrentPage();
  });

  // MutationObserver as a belt-and-suspenders fallback for SPA navigations
  const observer = new MutationObserver(() => checkCurrentPage());
  observer.observe(document.documentElement, { childList: true, subtree: false });

  checkCurrentPage();
})();

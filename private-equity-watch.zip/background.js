// background.js — MV3 service worker
// Manages the extension icon badge state on a per-tab basis.

const DEFAULT_ICON = {
  16:  "icons/icon16.png",
  48:  "icons/icon48.png",
  128: "icons/icon128.png",
};

const WARNING_ICON = {
  16:  "icons/icon-warning16.png",
  48:  "icons/icon-warning48.png",
  128: "icons/icon-warning128.png",
};

// --- Message handler ---

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.type !== "PAGE_CHECK_RESULT") return;

  const tabId = sender?.tab?.id;
  if (!tabId) return;

  if (message.isWarning) {
    setWarningIcon(tabId, message.ownerInfo);
  } else {
    clearWarningIcon(tabId);
  }
});

// --- Tab lifecycle ---

// Clear stale badge immediately when a new navigation begins,
// before the content script has had a chance to evaluate the new page.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    clearWarningIcon(tabId);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  // No persistent state to clean up, but clear any pending badge just in case.
  clearWarningIcon(tabId);
});

// --- Icon helpers ---

function setWarningIcon(tabId, ownerInfo) {
  const title = ownerInfo
    ? `Private Equity Watch: This channel is owned by ${ownerInfo}`
    : "Private Equity Watch: This channel is PE-owned";

  chrome.action.setBadgeText({ tabId, text: "PE" });
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#DC2626" });
  chrome.action.setTitle({ tabId, title });
  chrome.action.setIcon({ tabId, path: WARNING_ICON });
}

function clearWarningIcon(tabId) {
  chrome.action.setBadgeText({ tabId, text: "" });
  chrome.action.setTitle({ tabId, title: "Private Equity Watch" });
  chrome.action.setIcon({ tabId, path: DEFAULT_ICON });
}

// Load PE_ENTITIES into the global scope before content.js is required,
// mirroring how the browser loads pe-channels.js before content.js.
const { PE_ENTITIES } = require('../pe-channels.js');
global.PE_ENTITIES = PE_ENTITIES;

const {
  detectCurrentSite,
  detectByDomain,
  detectYouTube,
  extractHandleFromYtData,
} = require('../content.js');

// ---------------------------------------------------------------------------
// detectCurrentSite — top-level dispatcher
// ---------------------------------------------------------------------------

describe('detectCurrentSite — routing', () => {
  test('routes youtube.com to YouTube detection', () => {
    const result = detectCurrentSite('https://www.youtube.com/@veritasium');
    expect(result.isWarning).toBe(true);
  });

  test('routes youtu.be to YouTube detection', () => {
    // youtu.be short links go to watch pages; no channel in URL so no warning
    const result = detectCurrentSite('https://youtu.be/abc123');
    expect(result.isWarning).toBe(false);
  });

  test('routes other domains to domain detection', () => {
    // With an empty domains set, all non-YouTube sites return false
    const result = detectCurrentSite('https://buzzfeed.com/article/foo');
    expect(result.isWarning).toBe(false);
  });

  test('returns no warning for invalid URLs', () => {
    expect(detectCurrentSite('not-a-url').isWarning).toBe(false);
    expect(detectCurrentSite('').isWarning).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// detectByDomain — generic website detection
// ---------------------------------------------------------------------------

describe('detectByDomain', () => {
  // Temporarily add a domain to PE_ENTITIES for these tests
  beforeEach(() => {
    PE_ENTITIES.domains.add('example-pe-site.com');
    PE_ENTITIES.ownerInfo['example-pe-site.com'] = 'Test PE Firm';
  });

  afterEach(() => {
    PE_ENTITIES.domains.delete('example-pe-site.com');
    delete PE_ENTITIES.ownerInfo['example-pe-site.com'];
  });

  test('returns warning for a known PE-owned domain', () => {
    const result = detectByDomain('example-pe-site.com');
    expect(result.isWarning).toBe(true);
    expect(result.ownerInfo).toBe('Test PE Firm');
  });

  test('returns no warning for an unknown domain', () => {
    expect(detectByDomain('wikipedia.org').isWarning).toBe(false);
    expect(detectByDomain('github.com').isWarning).toBe(false);
  });

  test('www prefix is stripped before matching', () => {
    // detectCurrentSite strips www before calling detectByDomain
    const result = detectCurrentSite('https://www.example-pe-site.com/article');
    expect(result.isWarning).toBe(true);
  });

  test('subdomains do not match the bare domain', () => {
    expect(detectByDomain('news.example-pe-site.com').isWarning).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// detectYouTube — @handle URLs
// ---------------------------------------------------------------------------

describe('detectYouTube — @handle URLs', () => {
  function parse(url) { return new URL(url); }

  test('detects a known PE channel by handle', () => {
    const result = detectYouTube(parse('https://www.youtube.com/@veritasium'));
    expect(result.isWarning).toBe(true);
    expect(result.ownerInfo).toBe('Electrify Video Partners');
  });

  test('matching is case-insensitive', () => {
    expect(detectYouTube(parse('https://www.youtube.com/@Veritasium')).isWarning).toBe(true);
    expect(detectYouTube(parse('https://www.youtube.com/@VERITASIUM')).isWarning).toBe(true);
  });

  test('non-PE channel returns no warning', () => {
    expect(detectYouTube(parse('https://www.youtube.com/@mkbhd')).isWarning).toBe(false);
  });

  test('detects PE channel on sub-pages', () => {
    expect(detectYouTube(parse('https://www.youtube.com/@veritasium/videos')).isWarning).toBe(true);
    expect(detectYouTube(parse('https://www.youtube.com/@mrbeast/community')).isWarning).toBe(true);
  });

  test('detects each PE firm via a representative channel', () => {
    const cases = [
      ['https://www.youtube.com/@fireship',          'Electrify Video Partners'],
      ['https://www.youtube.com/@dudeperfect',        'Spotter'],
      ['https://www.youtube.com/@react',              'Electric Monster'],
      ['https://www.youtube.com/@gametheory',         'Lunar X'],
      ['https://www.youtube.com/@realstories',        'Little Dot Studios'],
      ['https://www.youtube.com/@donutmedia',         'Recurrent Ventures'],
    ];
    for (const [url, firm] of cases) {
      const result = detectYouTube(parse(url));
      expect(result.isWarning).toBe(true);
      expect(result.ownerInfo).toBe(firm);
    }
  });
});

describe('detectYouTube — legacy URL formats', () => {
  function parse(url) { return new URL(url); }

  test('/c/slug matches when slug equals a known handle', () => {
    expect(detectYouTube(parse('https://www.youtube.com/c/veritasium')).isWarning).toBe(true);
  });

  test('/user/username matches when username equals a known handle', () => {
    expect(detectYouTube(parse('https://www.youtube.com/user/veritasium')).isWarning).toBe(true);
  });

  test('/c/ with unknown slug returns no warning', () => {
    expect(detectYouTube(parse('https://www.youtube.com/c/unknownchannel')).isWarning).toBe(false);
  });
});

describe('detectYouTube — non-channel pages', () => {
  function parse(url) { return new URL(url); }

  test('YouTube homepage returns no warning', () => {
    expect(detectYouTube(parse('https://www.youtube.com/')).isWarning).toBe(false);
  });

  test('subscriptions feed returns no warning', () => {
    expect(detectYouTube(parse('https://www.youtube.com/feed/subscriptions')).isWarning).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// detectYouTube — /watch and /shorts pages (page-content detection)
// ---------------------------------------------------------------------------

describe('detectYouTube — /watch pages via ytInitialData', () => {
  function makeYtData(canonicalBaseUrl) {
    return {
      contents: {
        twoColumnWatchNextResults: {
          results: {
            results: {
              contents: [{
                videoSecondaryInfoRenderer: {
                  owner: {
                    videoOwnerRenderer: {
                      navigationEndpoint: {
                        browseEndpoint: { canonicalBaseUrl },
                      },
                    },
                  },
                },
              }],
            },
          },
        },
      },
    };
  }

  function parse(url) { return new URL(url); }

  beforeEach(() => { delete window.ytInitialData; });

  test('detects PE channel owner via ytInitialData', () => {
    window.ytInitialData = makeYtData('/@veritasium');
    expect(detectYouTube(parse('https://www.youtube.com/watch?v=abc')).isWarning).toBe(true);
  });

  test('no warning for non-PE channel via ytInitialData', () => {
    window.ytInitialData = makeYtData('/@mkbhd');
    expect(detectYouTube(parse('https://www.youtube.com/watch?v=abc')).isWarning).toBe(false);
  });

  test('no warning when ytInitialData is absent', () => {
    expect(detectYouTube(parse('https://www.youtube.com/watch?v=abc')).isWarning).toBe(false);
  });

  test('detects PE channel on a /shorts page', () => {
    window.ytInitialData = makeYtData('/@mrbeast');
    expect(detectYouTube(parse('https://www.youtube.com/shorts/abc')).isWarning).toBe(true);
  });
});

describe('detectYouTube — /watch pages via DOM fallback', () => {
  function parse(url) { return new URL(url); }

  beforeEach(() => {
    delete window.ytInitialData;
    document.body.innerHTML = '';
  });

  test('detects PE channel from DOM owner link', () => {
    document.body.innerHTML = `<ytd-channel-name><a href="/@veritasium">Channel</a></ytd-channel-name>`;
    expect(detectYouTube(parse('https://www.youtube.com/watch?v=abc')).isWarning).toBe(true);
  });

  test('no warning for non-PE channel in DOM owner link', () => {
    document.body.innerHTML = `<ytd-channel-name><a href="/@mkbhd">Channel</a></ytd-channel-name>`;
    expect(detectYouTube(parse('https://www.youtube.com/watch?v=abc')).isWarning).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// extractHandleFromYtData
// ---------------------------------------------------------------------------

describe('extractHandleFromYtData', () => {
  test('extracts handle from video watch page data', () => {
    const ytData = {
      contents: {
        twoColumnWatchNextResults: {
          results: { results: { contents: [{
            videoSecondaryInfoRenderer: {
              owner: { videoOwnerRenderer: {
                navigationEndpoint: { browseEndpoint: { canonicalBaseUrl: '/@veritasium' } },
              }},
            },
          }]}},
        },
      },
    };
    expect(extractHandleFromYtData(ytData)).toBe('veritasium');
  });

  test('extracts handle from channel page header data', () => {
    const ytData = {
      header: { c4TabbedHeaderRenderer: {
        navigationEndpoint: { browseEndpoint: { canonicalBaseUrl: '/@fireship' } },
      }},
    };
    expect(extractHandleFromYtData(ytData)).toBe('fireship');
  });

  test('returns null when no handle can be found', () => {
    expect(extractHandleFromYtData({})).toBeNull();
    expect(extractHandleFromYtData({ contents: {} })).toBeNull();
  });

  test('returns null for null/undefined without throwing', () => {
    expect(extractHandleFromYtData(null)).toBeNull();
    expect(extractHandleFromYtData(undefined)).toBeNull();
  });
});

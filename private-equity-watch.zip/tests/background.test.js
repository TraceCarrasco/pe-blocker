// background.test.js
// The chrome global must be set up before background.js is loaded, because
// background.js calls chrome.*addListener at module evaluation time.

// Capture registered listeners so tests can invoke them directly.
const listeners = {
  message: null,
  tabUpdated: null,
  tabRemoved: null,
};

global.chrome = {
  runtime: {
    onMessage: {
      addListener: jest.fn((fn) => { listeners.message = fn; }),
    },
  },
  action: {
    setBadgeText: jest.fn(),
    setBadgeBackgroundColor: jest.fn(),
    setTitle: jest.fn(),
    setIcon: jest.fn(),
  },
  tabs: {
    onUpdated: {
      addListener: jest.fn((fn) => { listeners.tabUpdated = fn; }),
    },
    onRemoved: {
      addListener: jest.fn((fn) => { listeners.tabRemoved = fn; }),
    },
  },
};

// Load background.js after chrome is mocked — it registers its listeners here.
require('../background.js');

beforeEach(() => {
  jest.clearAllMocks();
});

// ---------------------------------------------------------------------------
// Listener registration
// ---------------------------------------------------------------------------

describe('listener registration', () => {
  test('registers a message listener', () => {
    expect(typeof listeners.message).toBe('function');
  });

  test('registers a tabs.onUpdated listener', () => {
    expect(typeof listeners.tabUpdated).toBe('function');
  });

  test('registers a tabs.onRemoved listener', () => {
    expect(typeof listeners.tabRemoved).toBe('function');
  });
});

// ---------------------------------------------------------------------------
// PAGE_CHECK_RESULT — warning state
// ---------------------------------------------------------------------------

describe('PAGE_CHECK_RESULT: isWarning = true', () => {
  const sender = { tab: { id: 42 } };

  test('sets red badge text "PE"', () => {
    listeners.message({ type: 'PAGE_CHECK_RESULT', isWarning: true }, sender);
    expect(chrome.action.setBadgeText).toHaveBeenCalledWith({ tabId: 42, text: 'PE' });
  });

  test('sets red badge background colour', () => {
    listeners.message({ type: 'PAGE_CHECK_RESULT', isWarning: true }, sender);
    expect(chrome.action.setBadgeBackgroundColor).toHaveBeenCalledWith({ tabId: 42, color: '#DC2626' });
  });

  test('sets title naming the PE firm when ownerInfo is provided', () => {
    listeners.message(
      { type: 'PAGE_CHECK_RESULT', isWarning: true, ownerInfo: 'Spotter' },
      sender
    );
    expect(chrome.action.setTitle).toHaveBeenCalledWith({
      tabId: 42,
      title: 'Private Equity Watch: This channel is owned by Spotter',
    });
  });

  test('sets generic title when ownerInfo is null', () => {
    listeners.message(
      { type: 'PAGE_CHECK_RESULT', isWarning: true, ownerInfo: null },
      sender
    );
    expect(chrome.action.setTitle).toHaveBeenCalledWith({
      tabId: 42,
      title: 'Private Equity Watch: This channel is PE-owned',
    });
  });

  test('swaps to the warning icon', () => {
    listeners.message({ type: 'PAGE_CHECK_RESULT', isWarning: true }, sender);
    const call = chrome.action.setIcon.mock.calls[0][0];
    expect(call.tabId).toBe(42);
    expect(call.path[16]).toContain('warning');
  });
});

// ---------------------------------------------------------------------------
// PAGE_CHECK_RESULT — clear state
// ---------------------------------------------------------------------------

describe('PAGE_CHECK_RESULT: isWarning = false', () => {
  const sender = { tab: { id: 7 } };

  test('clears the badge text', () => {
    listeners.message({ type: 'PAGE_CHECK_RESULT', isWarning: false }, sender);
    expect(chrome.action.setBadgeText).toHaveBeenCalledWith({ tabId: 7, text: '' });
  });

  test('restores the default title', () => {
    listeners.message({ type: 'PAGE_CHECK_RESULT', isWarning: false }, sender);
    expect(chrome.action.setTitle).toHaveBeenCalledWith({ tabId: 7, title: 'Private Equity Watch' });
  });

  test('restores the default icon', () => {
    listeners.message({ type: 'PAGE_CHECK_RESULT', isWarning: false }, sender);
    const call = chrome.action.setIcon.mock.calls[0][0];
    expect(call.tabId).toBe(7);
    expect(call.path[16]).not.toContain('warning');
  });

  test('does not set a badge colour', () => {
    listeners.message({ type: 'PAGE_CHECK_RESULT', isWarning: false }, sender);
    expect(chrome.action.setBadgeBackgroundColor).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// Edge cases
// ---------------------------------------------------------------------------

describe('message listener edge cases', () => {
  test('ignores messages with unknown type', () => {
    listeners.message({ type: 'SOMETHING_ELSE', isWarning: true }, { tab: { id: 1 } });
    expect(chrome.action.setBadgeText).not.toHaveBeenCalled();
  });

  test('ignores messages with no sender tab', () => {
    listeners.message({ type: 'PAGE_CHECK_RESULT', isWarning: true }, {});
    expect(chrome.action.setBadgeText).not.toHaveBeenCalled();
  });

  test('ignores messages with undefined sender', () => {
    listeners.message({ type: 'PAGE_CHECK_RESULT', isWarning: true }, undefined);
    expect(chrome.action.setBadgeText).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// Tab lifecycle
// ---------------------------------------------------------------------------

describe('tabs.onUpdated', () => {
  test('clears badge when status is "loading"', () => {
    listeners.tabUpdated(99, { status: 'loading' });
    expect(chrome.action.setBadgeText).toHaveBeenCalledWith({ tabId: 99, text: '' });
  });

  test('does nothing when status is not "loading"', () => {
    listeners.tabUpdated(99, { status: 'complete' });
    expect(chrome.action.setBadgeText).not.toHaveBeenCalled();
  });

  test('does nothing when changeInfo has no status', () => {
    listeners.tabUpdated(99, {});
    expect(chrome.action.setBadgeText).not.toHaveBeenCalled();
  });
});

describe('tabs.onRemoved', () => {
  test('clears badge when a tab is closed', () => {
    listeners.tabRemoved(55);
    expect(chrome.action.setBadgeText).toHaveBeenCalledWith({ tabId: 55, text: '' });
  });
});

const { PE_CHANNELS } = require('../pe-channels.js');

describe('PE_CHANNELS structure', () => {
  test('handles is a Set', () => {
    expect(PE_CHANNELS.handles).toBeInstanceOf(Set);
  });

  test('ownerInfo is a plain object', () => {
    expect(PE_CHANNELS.ownerInfo).toBeDefined();
    expect(typeof PE_CHANNELS.ownerInfo).toBe('object');
    expect(Array.isArray(PE_CHANNELS.ownerInfo)).toBe(false);
  });

  test('handles set is non-empty', () => {
    expect(PE_CHANNELS.handles.size).toBeGreaterThan(0);
  });

  test('all handles are lowercase strings', () => {
    for (const handle of PE_CHANNELS.handles) {
      expect(typeof handle).toBe('string');
      expect(handle).toBe(handle.toLowerCase());
      expect(handle.trim().length).toBeGreaterThan(0);
    }
  });

  test('every handle has a matching ownerInfo entry', () => {
    for (const handle of PE_CHANNELS.handles) {
      expect(PE_CHANNELS.ownerInfo[handle]).toBeDefined();
      expect(typeof PE_CHANNELS.ownerInfo[handle]).toBe('string');
      expect(PE_CHANNELS.ownerInfo[handle].trim().length).toBeGreaterThan(0);
    }
  });

  test('every ownerInfo key exists in handles', () => {
    for (const key of Object.keys(PE_CHANNELS.ownerInfo)) {
      expect(PE_CHANNELS.handles.has(key)).toBe(true);
    }
  });
});

describe('PE_CHANNELS known channels', () => {
  test.each([
    ['veritasium',       'Electrify Video Partners'],
    ['fireship',         'Electrify Video Partners'],
    ['mrbeast',          'Spotter'],
    ['dudeperfect',      'Spotter'],
    ['thetryguys',       'Spotter'],
    ['react',            'Electric Monster'],
    ['gametheory',       'Lunar X'],
    ['economicsexplained','Lunar X'],
    ['realstories',      'Little Dot Studios'],
    ['donutmedia',       'Recurrent Ventures'],
  ])('%s is in the list and mapped to %s', (handle, firm) => {
    expect(PE_CHANNELS.handles.has(handle)).toBe(true);
    expect(PE_CHANNELS.ownerInfo[handle]).toBe(firm);
  });

  test('non-PE channels are not in the list', () => {
    const nonPE = ['mkbhd', 'linus', 'pewdiepie', 'tommyinnit', 'kurzgesagt'];
    for (const handle of nonPE) {
      expect(PE_CHANNELS.handles.has(handle)).toBe(false);
    }
  });
});

describe('PE_CHANNELS PE firm coverage', () => {
  const firms = Object.values(PE_CHANNELS.ownerInfo);

  test.each([
    'Electrify Video Partners',
    'Spotter',
    'Electric Monster',
    'Lunar X',
    'Little Dot Studios',
    'Recurrent Ventures',
  ])('%s has at least one channel', (firm) => {
    expect(firms).toContain(firm);
  });
});

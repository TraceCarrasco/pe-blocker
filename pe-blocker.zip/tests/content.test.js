// Load PE_CHANNELS into the global scope before content.js is required,
// mirroring how the browser loads pe-channels.js before content.js.
const { PE_CHANNELS } = require('../pe-channels.js');
global.PE_CHANNELS = PE_CHANNELS;

const { detectPEChannel, detectFromPage, extractHandleFromYtData } = require('../content.js');

// ---------------------------------------------------------------------------
// detectPEChannel — URL-based detection
// ---------------------------------------------------------------------------

describe('detectPEChannel — @handle URLs', () => {
  test('detects a known PE channel by handle', () => {
    const result = detectPEChannel('https://www.youtube.com/@veritasium');
    expect(result.isWarning).toBe(true);
    expect(result.ownerInfo).toBe('Electrify Video Partners');
  });

  test('matching is case-insensitive', () => {
    expect(detectPEChannel('https://www.youtube.com/@Veritasium').isWarning).toBe(true);
    expect(detectPEChannel('https://www.youtube.com/@VERITASIUM').isWarning).toBe(true);
    expect(detectPEChannel('https://www.youtube.com/@VeRiTaSiUm').isWarning).toBe(true);
  });

  test('non-PE channel returns no warning', () => {
    expect(detectPEChannel('https://www.youtube.com/@mkbhd').isWarning).toBe(false);
    expect(detectPEChannel('https://www.youtube.com/@kurzgesagt').isWarning).toBe(false);
  });

  test('detects PE channel on sub-pages (e.g. /videos, /about)', () => {
    expect(detectPEChannel('https://www.youtube.com/@veritasium/videos').isWarning).toBe(true);
    expect(detectPEChannel('https://www.youtube.com/@veritasium/about').isWarning).toBe(true);
    expect(detectPEChannel('https://www.youtube.com/@mrbeast/community').isWarning).toBe(true);
  });

  test('non-PE sub-page returns no warning', () => {
    expect(detectPEChannel('https://www.youtube.com/@mkbhd/videos').isWarning).toBe(false);
  });

  test('detects each PE firm via a representative channel', () => {
    const representatives = [
      ['https://www.youtube.com/@fireship',         'Electrify Video Partners'],
      ['https://www.youtube.com/@dudeperfect',       'Spotter'],
      ['https://www.youtube.com/@react',             'Electric Monster'],
      ['https://www.youtube.com/@gametheory',        'Lunar X'],
      ['https://www.youtube.com/@realstories',       'Little Dot Studios'],
      ['https://www.youtube.com/@donutmedia',        'Recurrent Ventures'],
    ];
    for (const [url, firm] of representatives) {
      const result = detectPEChannel(url);
      expect(result.isWarning).toBe(true);
      expect(result.ownerInfo).toBe(firm);
    }
  });
});

describe('detectPEChannel — legacy URL formats', () => {
  test('/c/slug matches when slug equals a known handle', () => {
    // veritasium is in handles; /c/veritasium should match
    expect(detectPEChannel('https://www.youtube.com/c/veritasium').isWarning).toBe(true);
  });

  test('/user/username matches when username equals a known handle', () => {
    expect(detectPEChannel('https://www.youtube.com/user/veritasium').isWarning).toBe(true);
  });

  test('/c/ with unknown slug returns no warning', () => {
    expect(detectPEChannel('https://www.youtube.com/c/unknownchannel').isWarning).toBe(false);
  });
});

describe('detectPEChannel — non-channel pages', () => {
  test('YouTube homepage returns no warning', () => {
    expect(detectPEChannel('https://www.youtube.com/').isWarning).toBe(false);
  });

  test('subscriptions feed returns no warning', () => {
    expect(detectPEChannel('https://www.youtube.com/feed/subscriptions').isWarning).toBe(false);
  });

  test('invalid URL returns no warning', () => {
    expect(detectPEChannel('not-a-url').isWarning).toBe(false);
    expect(detectPEChannel('').isWarning).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// detectPEChannel — /watch and /shorts pages (page-content detection)
// ---------------------------------------------------------------------------

describe('detectPEChannel — /watch pages via ytInitialData', () => {
  function makeYtData(canonicalBaseUrl) {
    return {
      contents: {
        twoColumnWatchNextResults: {
          results: {
            results: {
              contents: [
                {
                  videoSecondaryInfoRenderer: {
                    owner: {
                      videoOwnerRenderer: {
                        navigationEndpoint: {
                          browseEndpoint: { canonicalBaseUrl },
                        },
                      },
                    },
                  },
                },
              ],
            },
          },
        },
      },
    };
  }

  beforeEach(() => {
    delete window.ytInitialData;
  });

  test('detects PE channel owner via ytInitialData on a watch page', () => {
    window.ytInitialData = makeYtData('/@veritasium');
    const result = detectPEChannel('https://www.youtube.com/watch?v=abc123');
    expect(result.isWarning).toBe(true);
    expect(result.ownerInfo).toBe('Electrify Video Partners');
  });

  test('no warning for non-PE channel on a watch page', () => {
    window.ytInitialData = makeYtData('/@mkbhd');
    expect(detectPEChannel('https://www.youtube.com/watch?v=abc123').isWarning).toBe(false);
  });

  test('no warning when ytInitialData is absent', () => {
    expect(detectPEChannel('https://www.youtube.com/watch?v=abc123').isWarning).toBe(false);
  });

  test('detects PE channel on a /shorts page', () => {
    window.ytInitialData = makeYtData('/@mrbeast');
    expect(detectPEChannel('https://www.youtube.com/shorts/abc123').isWarning).toBe(true);
  });
});

describe('detectPEChannel — /watch pages via DOM fallback', () => {
  beforeEach(() => {
    delete window.ytInitialData;
    document.body.innerHTML = '';
  });

  function addOwnerLink(href) {
    document.body.innerHTML = `<ytd-channel-name><a href="${href}">Channel</a></ytd-channel-name>`;
  }

  test('detects PE channel from DOM owner link (@handle format)', () => {
    addOwnerLink('/@veritasium');
    expect(detectPEChannel('https://www.youtube.com/watch?v=abc123').isWarning).toBe(true);
  });

  test('no warning for non-PE channel in DOM owner link', () => {
    addOwnerLink('/@mkbhd');
    expect(detectPEChannel('https://www.youtube.com/watch?v=abc123').isWarning).toBe(false);
  });

  test('no warning when no owner link is in DOM', () => {
    expect(detectPEChannel('https://www.youtube.com/watch?v=abc123').isWarning).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// extractHandleFromYtData — unit tests
// ---------------------------------------------------------------------------

describe('extractHandleFromYtData', () => {
  test('extracts handle from video watch page data', () => {
    const ytData = {
      contents: {
        twoColumnWatchNextResults: {
          results: {
            results: {
              contents: [
                {
                  videoSecondaryInfoRenderer: {
                    owner: {
                      videoOwnerRenderer: {
                        navigationEndpoint: {
                          browseEndpoint: { canonicalBaseUrl: '/@veritasium' },
                        },
                      },
                    },
                  },
                },
              ],
            },
          },
        },
      },
    };
    expect(extractHandleFromYtData(ytData)).toBe('veritasium');
  });

  test('extracts handle from channel page header data', () => {
    const ytData = {
      header: {
        c4TabbedHeaderRenderer: {
          navigationEndpoint: {
            browseEndpoint: { canonicalBaseUrl: '/@fireship' },
          },
        },
      },
    };
    expect(extractHandleFromYtData(ytData)).toBe('fireship');
  });

  test('returns null when no handle can be found', () => {
    expect(extractHandleFromYtData({})).toBeNull();
    expect(extractHandleFromYtData({ contents: {} })).toBeNull();
  });

  test('returns null for null/undefined input without throwing', () => {
    expect(extractHandleFromYtData(null)).toBeNull();
    expect(extractHandleFromYtData(undefined)).toBeNull();
  });
});
